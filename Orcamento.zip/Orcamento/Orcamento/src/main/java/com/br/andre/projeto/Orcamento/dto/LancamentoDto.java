package com.br.andre.projeto.Orcamento.dto;

public class LancamentoDto {

    private Long id;

    private String datalancamento;

    private String tipolancamneto;

    private String valorlancamento;

    private String cliente;

    public LancamentoDto(Long id, String datalancamento, String tipolancamneto,
                         String valorlancamento, String cliente) {
        this.id = id;
        this.datalancamento = datalancamento;
        this.tipolancamneto = tipolancamneto;
        this.valorlancamento = valorlancamento;
        this.cliente = cliente;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getDatalancamento() {
        return datalancamento;
    }

    public void setDatalancamento(String datalancamento) {
        this.datalancamento = datalancamento;
    }

    public String getTipolancamneto() {
        return tipolancamneto;
    }

    public void setTipolancamneto(String tipolancamneto) {
        this.tipolancamneto = tipolancamneto;
    }

    public String getValorlancamento() {
        return valorlancamento;
    }

    public void setValorlancamento(String valorlancamento) {
        this.valorlancamento = valorlancamento;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
}
