package com.br.andre.projeto.Orcamento.controllers;

import com.br.andre.projeto.Orcamento.model.Municipio;
import com.br.andre.projeto.Orcamento.services.MunicipioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
@RequestMapping("/municipio")
@RestController
public class MunicipioController {
@Autowired
    private MunicipioService municipioService;
    @PostMapping()
    public ResponseEntity<Municipio> inserir(@RequestBody Municipio municipio){
        Municipio municipioSalva = municipioService.salvar(municipio);
        return ResponseEntity.status(HttpStatus.CREATED).body(municipioSalva);
    }
}
