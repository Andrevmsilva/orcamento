package com.br.andre.projeto.Orcamento.model;

import jakarta.persistence.*;
import org.springframework.boot.autoconfigure.web.WebProperties;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "Cliente")
public class Cliente {
@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

private String NomeCliente;

private String EnderecoCliente;

private String NumeroCliente;

private String BairroCliente;

private String TelefoneCliente;

private String CelularCliente;

@ManyToOne
@JoinColumn(name = "Municipio_id")
private Municipio Municipio;

@OneToMany(mappedBy = "Cliente")
private List<Lancamento> lancamentos_lista = new ArrayList<>();

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getNomeCliente() {
        return NomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        NomeCliente = nomeCliente;
    }

    public String getEnderecoCliente() {
        return EnderecoCliente;
    }

    public void setEnderecoCliente(String enderecoCliente) {
        EnderecoCliente = enderecoCliente;
    }

    public String getNumeroCliente() {
        return NumeroCliente;
    }

    public void setNumeroCliente(String numeroCliente) {
        NumeroCliente = numeroCliente;
    }

    public String getBairroCliente() {
        return BairroCliente;
    }

    public void setBairroCliente(String bairroCliente) {
        BairroCliente = bairroCliente;
    }

    public String getTelefoneCliente() {
        return TelefoneCliente;
    }

    public void setTelefoneCliente(String telefoneCliente) {
        TelefoneCliente = telefoneCliente;
    }

    public String getCelularCliente() {
        return CelularCliente;
    }

    public void setCelularCliente(String celularCliente) {
        CelularCliente = celularCliente;
    }

    public com.br.andre.projeto.Orcamento.model.Municipio getMunicipio() {
        return Municipio;
    }

    public void setMunicipio(com.br.andre.projeto.Orcamento.model.Municipio municipio) {
        Municipio = municipio;
    }

    public List<Lancamento> getLancamentos_lista() {
        return lancamentos_lista;
    }

    public void setLancamentos_lista(List<Lancamento> lancamentos_lista) {
        this.lancamentos_lista = lancamentos_lista;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Cliente cliente = (Cliente) o;
        return id == cliente.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
