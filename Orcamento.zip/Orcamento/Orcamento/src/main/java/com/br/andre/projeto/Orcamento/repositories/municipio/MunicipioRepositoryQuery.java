package com.br.andre.projeto.Orcamento.repositories.municipio;

import com.br.andre.projeto.Orcamento.model.Municipio;
import com.br.andre.projeto.Orcamento.repositories.filter.MunicipioFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface MunicipioRepositoryQuery {

    public Page<Municipio> filtrar(MunicipioFilter municipioFilter, Pageable pageable);
}
