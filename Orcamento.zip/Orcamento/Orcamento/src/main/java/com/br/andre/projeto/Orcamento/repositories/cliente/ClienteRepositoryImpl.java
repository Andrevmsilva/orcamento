package com.br.andre.projeto.Orcamento.repositories.cliente;

public class ClienteRepositoryImpl {
}
