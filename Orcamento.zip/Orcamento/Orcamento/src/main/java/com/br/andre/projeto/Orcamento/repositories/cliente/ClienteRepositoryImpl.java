package com.br.andre.projeto.Orcamento.repositories.cliente;

import com.br.andre.projeto.Orcamento.dto.ClienteDto;
import com.br.andre.projeto.Orcamento.model.Cliente;
import com.br.andre.projeto.Orcamento.repositories.filter.ClienteFilter;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.persistence.criteria.CriteriaBuilder;
import jakarta.persistence.criteria.CriteriaQuery;
import jakarta.persistence.criteria.Predicate;
import jakarta.persistence.criteria.Root;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.util.StringUtils;

import javax.swing.text.html.parser.Entity;
import java.util.ArrayList;
import java.util.List;

public class ClienteRepositoryImpl implements  ClienteRepositoryQuery{

    @PersistenceContext
    private EntityManager manager;

    @Override
    public Page<ClienteDto> filtrar(ClienteFilter clienteFilter, Pageable pageable) {
        CriteriaBuilder builder = manager.getCriteriaBuilder();
        CriteriaQuery<ClienteDto> criteria = builder.createQuery(ClienteDto.class);
        Root<Cliente> root = criteria.from(Cliente.class);

        criteria.select(builder.construct(ClienteDto.class,root.get("id"),
                root.get("nome"), root.get("endereco"), root.get("numero"),
                root.get("bairro"), root.get("telefone"), root.get("celular"),
                root.get("municipio").get("nome")));

        TypedQuery<ClienteDto> query = manager.createQuery(criteria);
        adicinarRestricoesDePaginacao(query,pageable);
        return new PageImpl<>(query.getResultList(),pageable,total(clienteFilter));
    }

    private long total(ClienteFilter clienteFilter) {
        CriteriaBuilder builder = manager.getCriteriaBuilder();
        CriteriaQuery<Long> criteria = builder.createQuery(Long.class);
        Root<Cliente> root = criteria.from(Cliente.class);

        Predicate[] predicates = criarRestricoes(clienteFilter,builder,root);
        criteria.where(predicates);
        criteria.select(builder.count(root));

        return manager.createQuery(criteria).getSingleResult();
    }

    private Predicate[] criarRestricoes(ClienteFilter clienteFilter, CriteriaBuilder builder, Root<Cliente> root) {
        List<Predicate> predicates = new ArrayList<>();
        if (!StringUtils.isEmpty(clienteFilter.getNome())){
            predicates.add(builder.like(builder.lower(root.get("nome")),
                    "%" + clienteFilter.getNome().toLowerCase()+ "%"));
        }
        if (!StringUtils.isEmpty(clienteFilter.getMunicipio())){
            predicates.add(builder.like(builder.lower(root.get("municipio").get("nome")),
                    "%" + clienteFilter.getMunicipio().toLowerCase()+ "%"));
        }
        return predicates.toArray(new Predicate[predicates.size()]);
    }

    private void adicinarRestricoesDePaginacao(TypedQuery<ClienteDto> query, Pageable pageable) {
        int paginaAtual = pageable.getPageNumber();
        int totalRegistrosPorPagina = pageable.getPageSize();
        int primeiroRegistroDaPagina = paginaAtual * totalRegistrosPorPagina;

        query.setFirstResult(primeiroRegistroDaPagina);
        query.setMaxResults(totalRegistrosPorPagina);
    }
}
