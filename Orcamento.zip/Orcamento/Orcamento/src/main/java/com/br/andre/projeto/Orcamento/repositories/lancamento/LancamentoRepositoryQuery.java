package com.br.andre.projeto.Orcamento.repositories.lancamento;

import com.br.andre.projeto.Orcamento.dto.LancamentoDto;
import com.br.andre.projeto.Orcamento.repositories.filter.LancamentoFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface LancamentoRepositoryQuery {

    public Page<LancamentoDto> filtrar(LancamentoFilter lancamentoFilter, Pageable pageable);
}
