package com.br.andre.projeto.Orcamento.model;

import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

@Entity
@Table(name = "Municipio")
public class Municipio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Municipio;

    private String NomeMunicipio;

    private String Estado;

    @OneToMany(mappedBy = "Municipio")
    private List<Cliente> Cliente_Lista = new ArrayList<>();

    public int getMunicipio() {
        return Municipio;
    }

    public void setMunicipio(int municipio) {
        Municipio = municipio;
    }

    public String getNomeMunicipio() {
        return NomeMunicipio;
    }

    public void setNomeMunicipio(String nomeMunicipio) {
        NomeMunicipio = nomeMunicipio;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String estado) {
        Estado = estado;
    }

    public List<Cliente> getCliente_Lista() {
        return Cliente_Lista;
    }

    public void setCliente_Lista(List<Cliente> cliente_Lista) {
        Cliente_Lista = cliente_Lista;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Municipio municipio = (Municipio) o;
        return Municipio == municipio.Municipio;
    }

    @Override
    public int hashCode() {
        return Objects.hash(Municipio);
    }
}
