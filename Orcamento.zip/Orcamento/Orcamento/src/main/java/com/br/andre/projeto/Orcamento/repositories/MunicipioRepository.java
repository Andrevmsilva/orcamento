package com.br.andre.projeto.Orcamento.repositories;

import com.br.andre.projeto.Orcamento.model.Municipio;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MunicipioRepository extends JpaRepository<Municipio,Integer> {
}
