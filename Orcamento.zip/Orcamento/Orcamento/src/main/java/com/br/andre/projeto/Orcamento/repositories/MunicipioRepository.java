package com.br.andre.projeto.Orcamento.repositories;

import com.br.andre.projeto.Orcamento.model.Municipio;
import com.br.andre.projeto.Orcamento.repositories.municipio.MunicipioRepositoryQuery;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MunicipioRepository extends JpaRepository<Municipio,Integer>, MunicipioRepositoryQuery {


}
