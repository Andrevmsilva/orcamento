package com.br.andre.projeto.Orcamento.repositories.cliente;

import com.br.andre.projeto.Orcamento.dto.ClienteDto;
import com.br.andre.projeto.Orcamento.repositories.filter.ClienteFilter;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface ClienteRepositoryQuery {

    public Page<ClienteDto> filtrar(ClienteFilter clienteFilter, Pageable pageable);

}
