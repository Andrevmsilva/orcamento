package com.br.andre.projeto.Orcamento.repositories;

import com.br.andre.projeto.Orcamento.model.Cliente;
import com.br.andre.projeto.Orcamento.repositories.cliente.ClienteRepositoryQuery;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente,Long>, ClienteRepositoryQuery {
}
