package com.br.andre.projeto.Orcamento.model;

import jakarta.persistence.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

@Entity
@Table(name = "Lancamento")
public class Lancamento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long lancamento;
    private LocalDate date;

    private String TipoLancamento;

    private BigDecimal ValorLancamento;

    @ManyToOne
    @JoinColumn(name = "Cliente_id")
    private Cliente Cliente;

    public long getLancamento() {
        return lancamento;
    }

    public void setLancamento(long lancamento) {
        this.lancamento = lancamento;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public String getTipoLancamento() {
        return TipoLancamento;
    }

    public void setTipoLancamento(String tipoLancamento) {
        TipoLancamento = tipoLancamento;
    }

    public BigDecimal getValorLancamento() {
        return ValorLancamento;
    }

    public void setValorLancamento(BigDecimal valorLancamento) {
        ValorLancamento = valorLancamento;
    }

    public com.br.andre.projeto.Orcamento.model.Cliente getCliente() {
        return Cliente;
    }

    public void setCliente(com.br.andre.projeto.Orcamento.model.Cliente cliente) {
        Cliente = cliente;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Lancamento that = (Lancamento) o;
        return lancamento == that.lancamento;
    }

    @Override
    public int hashCode() {
        return Objects.hash(lancamento);
    }
}
