package com.br.andre.projeto.Orcamento.services;

import com.br.andre.projeto.Orcamento.model.Cliente;
import com.br.andre.projeto.Orcamento.repositories.ClienteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ClienteService {
@Autowired
 private ClienteRepository clienteRepository;

 public Cliente salvar(Cliente cliente) {return clienteRepository.save(cliente);}

}
