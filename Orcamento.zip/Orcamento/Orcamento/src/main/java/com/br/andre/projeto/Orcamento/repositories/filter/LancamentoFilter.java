package com.br.andre.projeto.Orcamento.repositories.filter;

public class LancamentoFilter {
    private String datalancamento;

    private String tipolancamneto;

    private String valorlancamento;

    private String cliente;

    public String getDatalancamento() {
        return datalancamento;
    }

    public void setDatalancamento(String datalancamento) {
        this.datalancamento = datalancamento;
    }

    public String getTipolancamneto() {
        return tipolancamneto;
    }

    public void setTipolancamneto(String tipolancamneto) {
        this.tipolancamneto = tipolancamneto;
    }

    public String getValorlancamento() {
        return valorlancamento;
    }

    public void setValorlancamento(String valorlancamento) {
        this.valorlancamento = valorlancamento;
    }

    public String getCliente() {
        return cliente;
    }

    public void setCliente(String cliente) {
        this.cliente = cliente;
    }
}
