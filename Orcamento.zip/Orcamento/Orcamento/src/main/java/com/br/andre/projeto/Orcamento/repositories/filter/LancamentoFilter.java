package com.br.andre.projeto.Orcamento.repositories.filter;

public class LancamentoFilter {
}
