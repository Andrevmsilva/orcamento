
create table municipio(
id int not null primary key auto_increment,
nome varchar(100),
Estado varchar(100)
);

create table cliente(
id bigint not null primary key auto_increment,
nome varchar(100),
endereco varchar(100),
numero varchar(100),
bairro varchar(100),
municipio_id int not null,
telefone varchar(11),
celular varchar(11)
);

create table lancamento(
id bigint not null primary key auto_increment,
datalacamento date,
cliente_id bigint not null,
tipolacamento varchar(100),
valorlancamento decimal(10,2)
);

alter table  cliente add constraint fk_municipio_cliente
foreign key (municipio_id) references municipio(id);

alter table lancamento add constraint fk_cliente_lancamento
foreign key (cliente_id) references cliente(id);